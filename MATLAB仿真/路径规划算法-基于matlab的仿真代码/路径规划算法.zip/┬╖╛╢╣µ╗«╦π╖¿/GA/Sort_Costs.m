function [index] = Sort_Costs(costs)
%sort ascendly paths cost value 

[a, index] = sort(costs);

end

