# Running the code

1. Navigate to the code folder
2. Run "RRT.m" file

Note:
- other files are helper files for the above main scripts
- To switch between the three environment configurations, comment the others in RRT.m (well documented and commented code)
