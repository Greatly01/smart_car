%随机生成障碍物
function [f,n1]=ob(n)
f=[];%储存障碍物信息
n1=n;%返回障碍物个数
p=0;
for i=1:n
    k=1;
    while(k)
        D=[rand(1,2)*60+15,rand(1,1)*1+3];%随机生成障碍物的坐标与半径，自行调整
        if(distance(D(1),D(2),90,90)>(D(3)+5)) %与目标点距离一定长度，防止过多阻碍机器人到达目标点
            k=0;
        end
        for t=1:p  %障碍物之间的距离不能过窄，可自行调整去测试
            if(distance(D(1),D(2),f(3*t-2),f(3*t-1))<=(D(3)+f(3*t)+5))
                k=1;
            end
        end
    end
    %画出障碍物
    aplha=0:pi/40:2*pi;
    r=D(3);
    x=D(1)+r*cos(aplha);
    y=D(2)+r*sin(aplha);
    fill(x,y,'k');
    axis equal;
    hold on;
    xlim([0,100]);ylim([0,100]);
    f=[f,D];
    p=p+1;%目前生成的障碍物个数
end
hold all;