function f=distance(x,y,x1,y1)
   f=sqrt((x-x1)^2+(y-y1)^2);