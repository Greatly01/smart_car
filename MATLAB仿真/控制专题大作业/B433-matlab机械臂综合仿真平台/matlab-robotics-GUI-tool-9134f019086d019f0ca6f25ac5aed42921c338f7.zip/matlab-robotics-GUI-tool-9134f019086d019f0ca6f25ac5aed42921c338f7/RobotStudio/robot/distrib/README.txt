To build the .mltbx file

>> rvcver rtb dist   % set path
>> open RTB.prj

