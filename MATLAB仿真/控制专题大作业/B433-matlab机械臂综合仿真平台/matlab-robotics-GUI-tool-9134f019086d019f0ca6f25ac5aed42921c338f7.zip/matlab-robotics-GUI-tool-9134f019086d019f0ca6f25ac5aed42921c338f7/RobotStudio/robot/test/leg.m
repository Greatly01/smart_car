dh = 'Rz(q1).Rx(q2).Ty(L1).Rx(q3).Tz(L2)';
dh = dhfactor(dh);
dh
dh.base
dh.tool
dh.dh
dh.offset
dh.command('leg')
