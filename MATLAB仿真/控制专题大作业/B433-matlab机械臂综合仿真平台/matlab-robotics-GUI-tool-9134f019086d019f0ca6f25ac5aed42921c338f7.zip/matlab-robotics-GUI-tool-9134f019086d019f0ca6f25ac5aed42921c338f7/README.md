# matlab-robotics-GUI-tool
* 机械臂工具箱，基于matlab robotics toolbox
![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E5%85%B3%E8%8A%82%E7%A9%BA%E9%97%B4%E8%BF%90%E5%8A%A8.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E7%AC%9B%E5%8D%A1%E5%B0%94%E8%BF%90%E5%8A%A8.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E9%80%9F%E5%BA%A6%E6%A4%AD%E7%90%83.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E9%87%8D%E5%8A%9B%E8%B4%9F%E8%BD%BD%E5%88%86%E6%9E%90.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E9%9B%85%E5%85%8B%E6%AF%94%E7%9F%A9%E9%98%B5.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E9%80%9F%E5%BA%A6%E6%8E%A7%E5%88%B6.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E4%BD%8D%E7%BD%AE%E6%8E%A7%E5%88%B6.png)

![](https://github.com/borninfreedom/matlab-robotics-GUI-tool/blob/master/RobotStudio/PrintScreen/%E5%8A%9B%E7%9F%A9%E6%8E%A7%E5%88%B6.png)

## 安装方式
* 1. 将MATLAB的当前工作文件夹切换到 RobotStudio 文件夹。
* 2. 在命令行窗口中执行  
*    >> addpath common
* 	 >> startup_rvc
* 3. 双击RobotStudio.m, 点击执行开始执行。

# Installation introduction:
* 1. Change the Matlab working space to the "RobotStudio";
* 2. Command the following command lines:
*    >> addpath common
*    >> startup_rvc
* 3. Double click the RobotStudio.m file to execute.
